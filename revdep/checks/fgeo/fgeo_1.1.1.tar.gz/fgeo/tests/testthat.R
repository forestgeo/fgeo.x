library(testthat)
library(fgeo)

test_check("fgeo")
