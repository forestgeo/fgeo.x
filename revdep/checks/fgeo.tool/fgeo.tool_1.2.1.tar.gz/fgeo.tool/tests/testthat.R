library(testthat)
library(fgeo.tool)

test_check("fgeo.tool")
